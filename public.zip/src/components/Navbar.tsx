"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  Phone,
  Mail,
  Instagram,
  Facebook,
  Linkedin,
} from "lucide-react";

const NAV_LINKS = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#features" },
  { label: "Destinations", href: "#destinations" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Track viewport size for drawer animation direction
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 1023px)");
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  // Track scroll position for nav + contact bar state
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      const vh = window.innerHeight;
      setShowContact(y > vh * 0.4); // appears ~40% through hero
      setScrolled(y > vh * 0.85); // pill moves to bottom past hero
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock body scroll while drawer is open
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      {/* Contact bar — slides in at ~half hero */}
      <AnimatePresence>{showContact && <ContactBar key="cb" />}</AnimatePresence>

      {/* Pill nav — animates between top and bottom */}
      <motion.header
        initial={false}
        animate={{
          top: scrolled ? "auto" : showContact ? "3.25rem" : "1.5rem",
          bottom: scrolled ? "1.5rem" : "auto",
        }}
        transition={{ type: "spring", stiffness: 200, damping: 28 }}
        className="fixed left-1/2 z-50 w-[min(92%,720px)] -translate-x-1/2"
      >
        <div className="flex items-center justify-between rounded-full bg-white/95 p-1.5 pl-3 shadow-lift ring-1 ring-black/5 backdrop-blur-md">
          <Link href="/" className="flex items-center gap-2.5 pr-3">
            <Logo />
            <span className="font-heading text-base font-bold tracking-tight text-text-primary">
              Blue Elephant
            </span>
          </Link>
          <button
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((o) => !o)}
            className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-white transition hover:bg-primary"
          >
            <AnimatePresence mode="wait" initial={false}>
              {open ? (
                <motion.span
                  key="x"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.15 }}
                >
                  <X size={20} />
                </motion.span>
              ) : (
                <motion.span
                  key="menu"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.15 }}
                >
                  <Menu size={20} />
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </motion.header>

      <Drawer
        open={open}
        onClose={() => setOpen(false)}
        scrolled={scrolled}
        isMobile={isMobile}
      />
    </>
  );
}

/* ---------- Contact bar ---------- */

function ContactBar() {
  return (
    <motion.div
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: -40, opacity: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="fixed inset-x-0 top-0 z-40 bg-secondary text-white"
    >
      <div className="container-x flex h-10 items-center justify-between text-xs">
        <div className="flex items-center gap-6">
          <a
            href="tel:+910000000000"
            className="flex items-center gap-1.5 opacity-90 transition hover:opacity-100"
          >
            <Phone size={13} /> +91 00000 00000
          </a>
          <a
            href="mailto:hello@blueelephant.com"
            className="hidden items-center gap-1.5 opacity-90 transition hover:opacity-100 sm:flex"
          >
            <Mail size={13} /> hello@blueelephant.com
          </a>
        </div>
        <div className="flex items-center gap-4">
          <a
            href="#"
            aria-label="Instagram"
            className="opacity-90 transition hover:opacity-100"
          >
            <Instagram size={14} />
          </a>
          <a
            href="#"
            aria-label="Facebook"
            className="opacity-90 transition hover:opacity-100"
          >
            <Facebook size={14} />
          </a>
          <a
            href="#"
            aria-label="LinkedIn"
            className="opacity-90 transition hover:opacity-100"
          >
            <Linkedin size={14} />
          </a>
        </div>
      </div>
    </motion.div>
  );
}

/* ---------- Drawer ---------- */

function Drawer({
  open,
  onClose,
  scrolled,
  isMobile,
}: {
  open: boolean;
  onClose: () => void;
  scrolled: boolean;
  isMobile: boolean;
}) {
  // 4 variants:
  //   mobile + !scrolled  → slides L → R (covers half from left)
  //   mobile +  scrolled  → slides R → L (covers half from right)
  //   desktop + !scrolled → drops DOWN from below pill (top nav)
  //   desktop +  scrolled → rises UP   from above pill (bottom nav)

  let positionClass = "";
  let initial: Record<string, number | string> = {};
  let animate: Record<string, number | string> = {};
  let exit: Record<string, number | string> = {};
  let style: React.CSSProperties = {};

  if (isMobile) {
    if (scrolled) {
      positionClass =
        "fixed inset-y-0 right-0 w-[min(86%,400px)] rounded-l-3xl";
      initial = { x: "100%" };
      animate = { x: 0 };
      exit = { x: "100%" };
    } else {
      positionClass =
        "fixed inset-y-0 left-0 w-[min(86%,400px)] rounded-r-3xl";
      initial = { x: "-100%" };
      animate = { x: 0 };
      exit = { x: "-100%" };
    }
  } else {
    if (scrolled) {
      positionClass =
        "fixed left-1/2 -translate-x-1/2 bottom-28 w-[min(92%,720px)] rounded-3xl";
      initial = { opacity: 0, y: 24, scaleY: 0.7 };
      animate = { opacity: 1, y: 0, scaleY: 1 };
      exit = { opacity: 0, y: 24, scaleY: 0.7 };
      style = { transformOrigin: "bottom center" };
    } else {
      positionClass =
        "fixed left-1/2 -translate-x-1/2 top-32 w-[min(92%,720px)] rounded-3xl";
      initial = { opacity: 0, y: -24, scaleY: 0.7 };
      animate = { opacity: 1, y: 0, scaleY: 1 };
      exit = { opacity: 0, y: -24, scaleY: 0.7 };
      style = { transformOrigin: "top center" };
    }
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 z-[55] bg-black/45 backdrop-blur-sm"
          />

          <motion.aside
            key="panel"
            initial={initial}
            animate={animate}
            exit={exit}
            transition={{ type: "spring", stiffness: 240, damping: 28 }}
            style={style}
            className={`${positionClass} z-[60] overflow-hidden bg-secondary text-white shadow-lift`}
          >
            <DrawerContent isMobile={isMobile} onClose={onClose} />
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function DrawerContent({
  isMobile,
  onClose,
}: {
  isMobile: boolean;
  onClose: () => void;
}) {
  return (
    <div
      className={`flex flex-col ${
        isMobile ? "h-full p-8 pt-20" : "max-h-[70vh] p-10"
      }`}
    >
      <ul className="space-y-1">
        {NAV_LINKS.map((link, i) => (
          <motion.li
            key={link.href}
            initial={{ opacity: 0, x: 14 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.12 + i * 0.05 }}
          >
            <Link
              href={link.href}
              onClick={onClose}
              className="group flex items-center justify-between border-b border-white/10 py-4 font-heading font-semibold tracking-tight transition hover:text-accent"
            >
              <span className={isMobile ? "text-3xl" : "text-2xl"}>
                {link.label}
              </span>
              <span className="opacity-0 transition group-hover:opacity-60">
                →
              </span>
            </Link>
          </motion.li>
        ))}
      </ul>

      <div className={`pt-8 ${isMobile ? "mt-auto" : ""}`}>
        <Link
          href="#contact"
          onClick={onClose}
          className="btn-primary w-full justify-center"
        >
          Get In Touch
        </Link>
      </div>
    </div>
  );
}

/* ---------- Logo ---------- */

function Logo() {
  return (
    <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-brand shadow-sm">
      <svg viewBox="0 0 32 32" className="h-5 w-5" aria-hidden>
        <path
          fill="white"
          d="M8 14a8 8 0 0 1 16 0v5a4 4 0 0 1-4 4h-1v3h-3v-3h-4v3H9v-3a4 4 0 0 1-1-3v-2l-2-1a1 1 0 0 1 0-2l2-1z"
        />
      </svg>
    </div>
  );
}
