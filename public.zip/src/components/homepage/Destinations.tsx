"use client";

import Image from "next/image";
import { useState } from "react";
import { motion } from "framer-motion";

type Destination = {
  name: string;
  image: string;
  tag: "Worldwide" | "Popular" | "Exotic" | "Special Offers";
};

const ALL_DESTINATIONS: Destination[] = [
  {
    name: "Dubai",
    tag: "Popular",
    image:
      "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Kashmir",
    tag: "Popular",
    image:
      "https://images.unsplash.com/photo-1566837497312-7be4f47f5e98?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Goa",
    tag: "Popular",
    image:
      "https://images.unsplash.com/photo-1582972236019-ea4af5ffe587?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Maldives",
    tag: "Exotic",
    image:
      "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Jaipur",
    tag: "Popular",
    image:
      "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Keralam",
    tag: "Exotic",
    image:
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Bali",
    tag: "Worldwide",
    image:
      "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1400&q=80",
  },
  {
    name: "Santorini",
    tag: "Special Offers",
    image:
      "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1400&q=80",
  },
];

const TABS = ["Worldwide", "Popular", "Exotic", "Special Offers"] as const;

export default function Destinations() {
  const [active, setActive] = useState<(typeof TABS)[number]>("Popular");

  const visible = ALL_DESTINATIONS.filter((d) => d.tag === active);
  // fall back to all if a tab has too few, so the grid never looks empty
  const items = visible.length >= 4 ? visible.slice(0, 6) : ALL_DESTINATIONS.slice(0, 6);

  return (
    <section id="destinations" className="section bg-surface">
      <div className="container-x">
        <header className="text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-title"
          >
            Start Your Travel Planning Here
          </motion.h2>
          <p className="eyebrow mt-3">Discover our top destinations</p>

          {/* Tabs */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-10 gap-y-3">
            {TABS.map((tab) => {
              const isActive = tab === active;
              return (
                <button
                  key={tab}
                  onClick={() => setActive(tab)}
                  className="relative pb-2 text-xs font-semibold uppercase tracking-[0.18em] transition"
                  style={{
                    color: isActive ? "var(--text-primary)" : "var(--text-muted)",
                  }}
                >
                  {tab}
                  {isActive && (
                    <motion.span
                      layoutId="dest-underline"
                      className="absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full bg-accent"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </header>

        {/* Grid — 2 column, varied widths to mimic mockup */}
        <motion.div
          key={active}
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.08 } } }}
          className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-2"
        >
          {items.map((d) => (
            <DestinationCard key={d.name} destination={d} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function DestinationCard({ destination }: { destination: Destination }) {
  return (
    <motion.a
      href="#"
      variants={{
        hidden: { opacity: 0, y: 20 },
        show: { opacity: 1, y: 0, transition: { duration: 0.6 } },
      }}
      whileHover={{ y: -4 }}
      className="group relative block aspect-[16/10] overflow-hidden rounded-2xl shadow-card"
    >
      <Image
        src={destination.image}
        alt={destination.name}
        fill
        sizes="(max-width: 768px) 100vw, 50vw"
        className="object-cover transition-transform duration-700 group-hover:scale-110"
      />
      {/* darken on hover */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent transition-opacity duration-500 group-hover:opacity-90" />
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="relative font-heading text-4xl font-bold tracking-tight text-white drop-shadow-lg sm:text-5xl">
          {destination.name}
          <span className="absolute -bottom-2 left-1/2 h-0.5 w-12 -translate-x-1/2 bg-white" />
        </span>
      </div>
    </motion.a>
  );
}
