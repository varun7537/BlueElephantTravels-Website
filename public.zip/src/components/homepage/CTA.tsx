"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section id="contact" className="section">
      <div className="container-x">
        <div className="relative isolate overflow-hidden rounded-3xl bg-gradient-brand px-6 py-16 text-center text-white shadow-lift sm:px-12 sm:py-20">
          {/* Floating decorative shapes */}
          <Shape className="-left-10 top-8 h-32 w-32" delay={0} />
          <Shape className="right-10 top-20 h-20 w-20" delay={1.2} />
          <Shape className="-bottom-12 left-1/3 h-40 w-40" delay={2.4} />
          <Shape className="-right-16 bottom-0 h-48 w-48" delay={0.6} />

          <div className="grain" />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative mx-auto max-w-2xl"
          >
            <span className="inline-block rounded-full border border-white/30 bg-white/10 px-4 py-1.5 text-xs font-medium tracking-wider backdrop-blur">
              READY WHEN YOU ARE
            </span>
            <h2 className="mt-5 text-white">
              Let&apos;s plan a journey worth remembering.
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-white/85">
              Tell us where you want to go — we&apos;ll handle the rest. From visa to villa, every
              detail is taken care of.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <Link
                href="#hero"
                className="inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 font-semibold text-primary shadow-soft transition hover:-translate-y-0.5"
              >
                Get Started <ArrowRight size={18} />
              </Link>
              <Link
                href="#features"
                className="inline-flex items-center gap-2 rounded-full border border-white/50 px-7 py-3.5 font-semibold text-white transition hover:bg-white/10"
              >
                Learn More
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Shape({ className, delay }: { className: string; delay: number }) {
  return (
    <motion.span
      aria-hidden
      initial={{ opacity: 0, scale: 0.6 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.2, delay: delay * 0.2 }}
      className={`absolute rounded-full bg-white/15 blur-2xl ${className}`}
      style={{
        animation: `float-slow 7s ease-in-out ${delay}s infinite`,
      }}
    />
  );
}
