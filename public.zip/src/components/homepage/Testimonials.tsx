"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";

type Review = {
  quote: string;
  author: string;
  location: string;
};

const REVIEWS: Review[] = [
  {
    quote:
      "Blue Elephant made our honeymoon in Kerala absolutely magical. The attention to detail and personal touch were unmatched — every moment felt curated just for us.",
    author: "Dexter Morgan",
    location: "UK",
  },
  {
    quote:
      "From the wildlife safari in Ranthambore to the heritage stay in Jaipur, every leg of the trip felt thoughtfully designed. The guides were storytellers, not just informers.",
    author: "Priya Iyer",
    location: "Singapore",
  },
  {
    quote:
      "We've travelled with many agencies, but Blue Elephant raised the bar. The Maldives villa, the private dinners, the quiet attention — it spoiled us for any other travel.",
    author: "Marc & Lina Rousseau",
    location: "France",
  },
  {
    quote:
      "They listened, they adapted, and they delivered. Our family of seven across three age groups all came home raving — that's a small miracle in itself.",
    author: "Aman Sethi",
    location: "Toronto",
  },
];

export default function Testimonials() {
  const [index, setIndex] = useState(0);

  // Auto-advance
  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % REVIEWS.length), 6500);
    return () => clearInterval(id);
  }, []);

  const review = REVIEWS[index];

  return (
    <section id="testimonials" className="section">
      <div className="container-x">
        <div className="relative isolate overflow-hidden rounded-3xl shadow-lift">
          {/* Background image */}
          <Image
            src="https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=2000&q=80"
            alt=""
            fill
            sizes="100vw"
            className="-z-20 object-cover"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-br from-amber-900/40 via-secondary/35 to-secondary/55" />

          <div className="relative px-6 py-16 text-center text-white sm:px-12 sm:py-20">
            <h3 className="font-heading text-2xl font-bold tracking-[0.18em] sm:text-3xl">
              CUSTOMER REVIEWS
            </h3>

            <div className="mx-auto mt-8 min-h-[180px] max-w-3xl">
              <AnimatePresence mode="wait">
                <motion.blockquote
                  key={index}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -16 }}
                  transition={{ duration: 0.5 }}
                  className="text-base leading-relaxed text-white/95 sm:text-lg"
                >
                  &ldquo;{review.quote}&rdquo;
                  <footer className="mt-6 text-sm font-medium text-white/85">
                    — {review.author}, {review.location}
                  </footer>
                </motion.blockquote>
              </AnimatePresence>
            </div>

            {/* Dots */}
            <div className="mt-8 flex items-center justify-center gap-2.5">
              {REVIEWS.map((_, i) => {
                const isActive = i === index;
                return (
                  <button
                    key={i}
                    onClick={() => setIndex(i)}
                    aria-label={`Show review ${i + 1}`}
                    className="rounded-full transition-all"
                    style={{
                      width: isActive ? "28px" : "10px",
                      height: "10px",
                      background: isActive ? "var(--accent)" : "rgba(255,255,255,0.45)",
                    }}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
