"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { MapPin, Calendar, Search } from "lucide-react";

const STATS = [
  { value: "559+", label: "Guided Tours" },
  { value: "150+", label: "Destinations" },
  { value: "90.5%", label: "Satisfaction" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.2, 0.8, 0.2, 1], delay: i * 0.08 },
  }),
};

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative isolate flex min-h-[100svh] flex-col justify-center overflow-hidden pb-20 pt-44 text-white"
    >
      {/* Background image */}
      <Image
        src="https://images.unsplash.com/photo-1689961962572-988369409784?auto=format&fit=crop&w=1400&q=80"
        alt=""
        fill
        priority
        sizes="100vw"
        className="-z-20 object-cover"
      />
      {/* Dark wash + brand tint */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-secondary/85 via-secondary/55 to-secondary/85" />
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_rgba(56,189,248,0.18),_transparent_55%)]" />

      {/* Floating decorative orbs */}
      <div className="gradient-orb -left-32 top-1/4 h-72 w-72 bg-accent/40 animate-float-slow" />
      <div className="gradient-orb -right-24 bottom-1/3 h-80 w-80 bg-primary-light/40 animate-float-slow [animation-delay:-3s]" />

      <div className="container-x relative z-10">
        <motion.div
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.1 } } }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.span
            variants={fadeUp}
            className="inline-block rounded-full border border-white/25 bg-white/10 px-4 py-1.5 text-xs font-medium tracking-wider text-white/90 backdrop-blur"
          >
            ✨ CURATED LUXURY TRAVEL
          </motion.span>

          <motion.h1 variants={fadeUp} className="mt-6 text-white">
            Where Journeys Meet{" "}
            <span className="bg-gradient-to-r from-accent via-white to-accent bg-clip-text text-transparent">
              Royal Hospitality
            </span>
          </motion.h1>

          <motion.p
            variants={fadeUp}
            className="mx-auto mt-5 max-w-xl text-base text-white/80 sm:text-lg"
          >
            Discover comfort, elegance, and tradition — all in one place.
          </motion.p>

          {/* Search bar */}
          <motion.div variants={fadeUp} className="mt-10">
            <SearchBar />
          </motion.div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          variants={{ show: { transition: { staggerChildren: 0.12, delayChildren: 0.2 } } }}
          className="mx-auto mt-20 max-w-3xl border-t border-white/20 pt-8"
        >
          <div className="grid grid-cols-3 gap-6">
            {STATS.map((s, i) => (
              <motion.div
                key={s.label}
                custom={i}
                variants={fadeUp}
                className="text-center"
              >
                <div className="font-heading text-3xl font-bold text-white sm:text-4xl">
                  {s.value}
                </div>
                <div className="mt-1.5 text-xs uppercase tracking-wider text-white/70 sm:text-sm sm:normal-case sm:tracking-normal">
                  {s.label}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function SearchBar() {
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-1 rounded-[32px] bg-white/95 p-1.5 shadow-lift backdrop-blur md:flex-row md:items-center md:rounded-full">
      <SearchField icon={<MapPin size={16} />} placeholder="Start Location" />
      <Divider />
      <SearchField icon={<MapPin size={16} />} placeholder="End Location" />
      <Divider />
      <SearchField icon={<Calendar size={16} />} placeholder="Start Date" />
      <Divider />
      <SearchField icon={<Calendar size={16} />} placeholder="End Date" />
      <button
        type="button"
        className="ml-auto mt-1 inline-flex items-center justify-center gap-2 rounded-full bg-secondary px-6 py-3 text-sm font-semibold text-white transition hover:bg-primary md:mt-0"
      >
        <Search size={16} />
        Search
      </button>
    </div>
  );
}

function SearchField({
  icon,
  placeholder,
}: {
  icon: React.ReactNode;
  placeholder: string;
}) {
  return (
    <label className="flex flex-1 items-center gap-2 rounded-full px-4 py-2.5 text-left transition hover:bg-slate-50">
      <span className="text-slate-500">{icon}</span>
      <input
        type="text"
        placeholder={placeholder}
        className="w-full bg-transparent text-sm text-slate-700 placeholder:text-slate-500 focus:outline-none"
      />
    </label>
  );
}

function Divider() {
  return <span className="hidden h-6 w-px bg-slate-200 md:block" />;
}
