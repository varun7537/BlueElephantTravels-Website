"use client";

import { motion } from "framer-motion";
import {
  Plane,
  Building2,
  Compass,
  PawPrint,
  Heart,
  Users,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type Feature = {
  icon: LucideIcon;
  title: string;
  description: string;
  iconBg: string;
  iconColor: string;
};

const FEATURES: Feature[] = [
  {
    icon: Plane,
    title: "Custom Itineraries",
    description:
      "We craft bespoke travel plans aligned with your interests, pace, and budget — no two trips are ever the same.",
    iconBg: "bg-sky-100",
    iconColor: "text-sky-600",
  },
  {
    icon: Building2,
    title: "Luxury Accommodations",
    description:
      "Handpicked heritage hotels, boutique retreats, and jungle lodges that elevate your stay to an experience in itself.",
    iconBg: "bg-rose-100",
    iconColor: "text-rose-600",
  },
  {
    icon: Compass,
    title: "Expert Local Guides",
    description:
      "Our knowledgeable guides bring history, culture and hidden stories to life — turning sightseeing into storytelling.",
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
  {
    icon: PawPrint,
    title: "Wildlife Safaris",
    description:
      "From tiger sightings in Ranthambore to elephant encounters in Kabini — unforgettable wildlife experiences await.",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
  },
  {
    icon: Heart,
    title: "Honeymoon Packages",
    description:
      "Romantic getaways crafted with special touches — candlelit dinners, spa treatments, and breathtaking sunsets.",
    iconBg: "bg-pink-100",
    iconColor: "text-pink-600",
  },
  {
    icon: Users,
    title: "Group & Family Tours",
    description:
      "Seamlessly coordinated group tours and family vacations that create shared memories to last a lifetime.",
    iconBg: "bg-violet-100",
    iconColor: "text-violet-600",
  },
];

export default function Features() {
  return (
    <section id="features" className="section bg-background">
      <div className="container-x">
        <header className="mx-auto max-w-2xl text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-title"
          >
            Travel Crafted with Care
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-subtitle"
          >
            Every journey we plan is tailored to your dreams — we handle every detail so you can
            focus on making memories.
          </motion.p>
        </header>

        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          variants={{ show: { transition: { staggerChildren: 0.08 } } }}
          className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3"
        >
          {FEATURES.map((f) => (
            <FeatureCard key={f.title} feature={f} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function FeatureCard({ feature }: { feature: Feature }) {
  const Icon = feature.icon;
  return (
    <motion.article
      variants={{
        hidden: { opacity: 0, y: 24 },
        show: { opacity: 1, y: 0, transition: { duration: 0.55 } },
      }}
      className="feature-card group relative"
    >
      <div
        className={`mb-5 inline-grid h-12 w-12 place-items-center rounded-xl ${feature.iconBg} transition-transform group-hover:scale-110`}
      >
        <Icon className={feature.iconColor} size={22} strokeWidth={2.2} />
      </div>
      <h5 className="mb-2 text-text-primary">{feature.title}</h5>
      <p className="text-sm">{feature.description}</p>

      {/* hover glow */}
      <div className="pointer-events-none absolute inset-0 -z-10 rounded-[var(--radius-lg)] bg-gradient-to-br from-primary/0 via-primary/0 to-accent/0 opacity-0 transition-opacity group-hover:opacity-10" />
    </motion.article>
  );
}
