"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Instagram as InstagramIcon } from "lucide-react";

const FEED = [
  "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1486591038492-6a3f7eed68a7?auto=format&fit=crop&w=600&q=80",
];

export default function Instagram() {
  return (
    <section id="instagram" className="section pt-0">
      <div className="container-x">
        <div className="grid gap-8 lg:grid-cols-[260px,1fr] lg:gap-10">
          {/* Left column */}
          <div className="flex flex-col items-start gap-4 lg:pt-4">
            <InstagramIcon size={32} className="text-text-primary" strokeWidth={1.5} />
            <a
              href="#"
              className="inline-flex w-full max-w-[180px] items-center justify-center rounded-md border border-text-primary px-8 py-2.5 text-sm font-semibold text-text-primary transition hover:bg-text-primary hover:text-white"
            >
              FOLLOW
            </a>
            <div className="mt-2 h-px w-32 bg-border" />
            <p className="text-sm text-text-secondary">
              Follow us &amp; Share your &apos;Blueelephanttravels&apos; experience with us
            </p>
            <p className="mt-3 font-heading text-base font-semibold text-text-primary">
              #Blueelephanttravels
            </p>
          </div>

          {/* Image grid */}
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-50px" }}
            variants={{ show: { transition: { staggerChildren: 0.04 } } }}
            className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5"
          >
            {FEED.map((src, i) => (
              <motion.a
                key={i}
                href="#"
                variants={{
                  hidden: { opacity: 0, scale: 0.95 },
                  show: { opacity: 1, scale: 1, transition: { duration: 0.4 } },
                }}
                className="group relative aspect-square overflow-hidden rounded-md"
              >
                <Image
                  src={src}
                  alt={`Instagram post ${i + 1}`}
                  fill
                  sizes="(max-width: 768px) 33vw, 200px"
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-secondary/0 transition group-hover:bg-secondary/30" />
                <InstagramIcon
                  size={14}
                  className="absolute bottom-1.5 right-1.5 text-white opacity-90 drop-shadow"
                />
              </motion.a>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
