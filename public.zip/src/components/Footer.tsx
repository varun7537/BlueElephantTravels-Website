import Link from "next/link";
import { Mail, MapPin, Phone } from "lucide-react";

const COLUMNS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Company",
    links: [
      { label: "About Us", href: "#about" },
      { label: "Our Story", href: "#about" },
      { label: "Careers", href: "#" },
      { label: "Press", href: "#" },
    ],
  },
  {
    title: "Experiences",
    links: [
      { label: "Custom Itineraries", href: "#features" },
      { label: "Wildlife Safaris", href: "#features" },
      { label: "Honeymoons", href: "#features" },
      { label: "Group Tours", href: "#features" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Contact", href: "#contact" },
      { label: "FAQs", href: "#" },
      { label: "Privacy", href: "#" },
      { label: "Terms", href: "#" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-secondary text-white">
      <div className="container-x py-16">
        <div className="grid gap-10 lg:grid-cols-[1.4fr,1fr,1fr,1fr,1.2fr]">
          {/* Brand block */}
          <div>
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-white">
                <svg viewBox="0 0 32 32" className="h-6 w-6" aria-hidden>
                  <path
                    fill="#0F52BA"
                    d="M8 14a8 8 0 0 1 16 0v5a4 4 0 0 1-4 4h-1v3h-3v-3h-4v3H9v-3a4 4 0 0 1-1-3v-2l-2-1a1 1 0 0 1 0-2l2-1z"
                  />
                </svg>
              </div>
              <span className="font-heading text-xl font-bold">Blue Elephant</span>
            </div>
            <p className="mt-4 max-w-sm text-sm text-white/70">
              Where journeys meet royal hospitality. Bespoke travel experiences crafted with care,
              culture, and a sense of wonder.
            </p>
          </div>

          {/* Link columns */}
          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h6 className="text-white">{col.title}</h6>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/70 transition hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact */}
          <div>
            <h6 className="text-white">Get in Touch</h6>
            <ul className="mt-4 space-y-3 text-sm text-white/70">
              <li className="flex items-start gap-2.5">
                <MapPin size={16} className="mt-0.5 flex-shrink-0 text-accent" />
                <span>Krishna Nagar, Delhi, India</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone size={16} className="text-accent" />
                <a href="tel:+910000000000" className="hover:text-white">
                  +91 00000 00000
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail size={16} className="text-accent" />
                <a href="mailto:hello@blueelephant.com" className="hover:text-white">
                  hello@blueelephant.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-white/55 sm:flex-row">
          <p>© {new Date().getFullYear()} Blue Elephant. All rights reserved.</p>
          <p>
            Crafted with care in Delhi.
          </p>
        </div>
      </div>
    </footer>
  );
}
