import {
  Hero,
  Destinations,
  Features,
  Testimonials,
  Instagram,
  CTA,
} from "@/components/homepage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Destinations />
        <Features />
        <Testimonials />
        <CTA />
        <Instagram />
      </main>
      <Footer />
    </>
  );
}
